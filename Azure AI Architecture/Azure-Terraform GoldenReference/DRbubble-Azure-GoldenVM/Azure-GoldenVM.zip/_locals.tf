# This file should only contain local variable declarations that are used globally within a module. If
# a local is defined to support creation of a specific resource, that local should be included in the same
# .tf file as the resource being created to improve code readability.

locals {
  tags = merge(
    var.required_tags,
    var.optional_tags
  )
  data_tags = merge(
    var.required_tags,
    var.optional_tags,
    var.required_data_tags,
    var.optional_data_tags
  )
  linux_gallery               = "LinuxComputeGallery"
  windows_gallery             = "WindowsComputeGallery"
  gallery_resource_group_name = "computegallery-rg"
}
