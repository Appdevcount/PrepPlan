output "vm_id" {
  value = var.os_type == "Linux" ? azurerm_linux_virtual_machine.linux-vm[0].id : azurerm_windows_virtual_machine.windows-vm[0].id
}
output "vm_identity" {
  value = var.os_type == "Linux" ? azurerm_linux_virtual_machine.linux-vm[0].identity : azurerm_windows_virtual_machine.windows-vm[0].identity
}